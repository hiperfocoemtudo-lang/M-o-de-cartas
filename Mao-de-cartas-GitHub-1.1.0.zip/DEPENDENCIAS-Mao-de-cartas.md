# Dependências — Mão de cartas 1.1.0

O instalador `instalar.sh` instala automaticamente os pacotes abaixo pelo APT. O pacote `.deb` declara as mesmas dependências: ao abri-lo no instalador de pacotes do Mint, ou instalá-lo com `sudo apt install ./mao-de-cartas-applet_1.1.0_all.deb`, o sistema também instala o que faltar.

## Pacotes obrigatórios

| Pacote | Uso |
| --- | --- |
| `cinnamon` (6.0 ou posterior no `.deb`) | Painel, applets, configurações e execução JavaScript pelo CJS. |
| `python3` (3.9 ou posterior) | Tela de aplicativos, gerador e instalador local. |
| `python3-gi` | Acesso do Python às bibliotecas gráficas do sistema. |
| `gir1.2-gtk-3.0` | GTK 3 e GDK: janelas, controles, seletores de arquivos e catálogo visual. |
| `gir1.2-webkit2-4.1` | Editor de cartas embutido; a interface 4.1 é obrigatória nesta versão. |
| `gir1.2-gdkpixbuf-2.0` | Leitura, dimensionamento e prévias de imagens. |
| `gir1.2-glib-2.0` | GLib, GObject, Gio e GioUnix: aplicativos `.desktop`, arquivos, eventos e D-Bus. |
| `gir1.2-clutter-1.0` | Atores gráficos, transformações e interação das cartas. |
| `gir1.2-cogl-1.0` | Texturas e composição gráfica das cartas. |
| `ca-certificates` | Verificação dos certificados HTTPS do gerador online. |

O comando usado pelo instalador é:

```bash
sudo apt-get update
sudo apt-get install -y cinnamon python3 python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1 gir1.2-gdkpixbuf-2.0 gir1.2-glib-2.0 gir1.2-clutter-1.0 gir1.2-cogl-1.0 ca-certificates
```

## Dependências instaladas indiretamente

O APT resolve todas as dependências transitivas dos pacotes acima, usando as versões disponíveis na distribuição. Isso inclui o motor `libwebkit2gtk-4.1-0`, JavaScriptCoreGTK, GTK/GDK 3, GdkPixbuf, GLib/GObject/Gio, libsoup 3, Clutter, Cogl, bibliotecas de fontes/imagens/gráficos e os componentes do Cinnamon/CJS. Elas não devem ser baixadas ou copiadas manualmente. Os nomes exatos e o conjunto completo de pacotes transitivos variam entre versões do Mint e arquiteturas.

Os módulos `imports.ui.*`, `imports.misc.util`, `St` e `Tweener` vêm do próprio Cinnamon. A sessão precisa estar executando Cinnamon, com o barramento D-Bus do usuário e o sistema de configurações funcionando. Instalar o pacote `cinnamon` dentro de uma sessão MATE ou Xfce não ativa a applet nessa sessão: é necessário entrar na sessão Cinnamon.

## Bibliotecas Python e arquivos já incluídos

Não é necessário instalar nenhum pacote com `pip`. Os módulos Python adicionais usados — `base64`, `copy`, `datetime`, `fcntl`, `functools`, `hashlib`, `importlib`, `http`, `json`, `os`, `pathlib`, `random`, `secrets`, `shutil`, `subprocess`, `sys`, `tempfile`, `threading` e `urllib` — fazem parte da biblioteca padrão.

Os scripts JavaScript/CSS, fontes da interface e a integração do editor estão incluídos no pacote. Não é necessário instalar Node.js, npm, navegador separado, ImageMagick, Docker, Pillow ou um servidor web separado. O processo Python do editor abre seu próprio servidor apenas em `127.0.0.1`, numa porta temporária.

Para usar o instalador ZIP: Bash, `sudo`, APT e um extrator ZIP (o gerenciador de arquivos do Mint já fornece essa função). O `.deb` dispensa o extrator ZIP.

## Dependência online

A geração e as prévias completas dependem do serviço HTTPS **https://generator.cards/** na porta 443. O editor envia o nome, as imagens e as opções da carta a esse servidor. A prévia local de tamanho da logo responde imediatamente; a carta inteira acompanha o processamento remoto. Alterações ou indisponibilidade do site podem exigir atualização desta integração.

As cartas já salvas e o lançamento dos aplicativos funcionam sem internet. Os aplicativos que você quiser lançar precisam estar instalados na outra máquina; seus identificadores `.desktop` podem ser diferentes.

## Compatibilidade e versão conferida

Conferido nesta máquina: Linux Mint **22.3**, Cinnamon **6.6.9**, Python **3.12.3**, PyGObject **3.48.2**, GTK **3.24.41**, GdkPixbuf **2.42.10**, GLib **2.80**, Clutter **1.26.4**, Cogl **1.22.8** e WebKitGTK **2.52.6**, com a interface WebKit2 **4.1**. Esses números são referência de teste, não exigências de versões exatas. O pacote é independente da arquitetura e usa as bibliotecas nativas que o APT instalar.

Recomendado: Linux Mint 22.x Cinnamon. Outras versões e LMDE com os mesmos pacotes podem funcionar, mas não foram testadas. O `.deb` exige Cinnamon >= 6.0 e Python >= 3.9 como base declarada; isso não equivale a ter testado todas as versões desde esses mínimos. WebKit2 4.0 não substitui 4.1 neste código.

Fontes dos pacotes: [WebKit2 4.1 e suas dependências no Ubuntu 24.04](https://packages.ubuntu.com/noble/gir1.2-webkit2-4.1), além da lista de pacotes e importações conferidas nesta máquina.

As cartas automáticas também usam o gerador online na primeira criação, preferem ícones simbólicos do tema e são guardadas localmente. O módulo padrão `fcntl` serializa a fila para evitar gerações duplicadas.
