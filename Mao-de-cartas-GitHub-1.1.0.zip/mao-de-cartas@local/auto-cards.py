#!/usr/bin/python3
"""Generate and cache default cards once, without altering user customizations."""
import os
import base64, fcntl, hashlib, importlib.util, json, random, secrets, sys, threading
from pathlib import Path
import gi
gi.require_version('Gtk','3.0')
gi.require_version('WebKit2','4.1')
from gi.repository import Gtk, Gdk, Gio, GLib, WebKit2
spec=importlib.util.spec_from_file_location('generator_window',Path(__file__).with_name('generator-window.py'))
generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
ROOT=Path(GLib.get_user_data_dir())/'mao-de-cartas'/'defaults'
ROOT.mkdir(parents=True,exist_ok=True)

def initial_for(app):
    icon=app.get_icon() or Gio.ThemedIcon.new('application-x-executable')
    theme=Gtk.IconTheme.get_default()
    names=[]
    if isinstance(icon,Gio.ThemedIcon):names.extend(icon.get_names())
    app_id=app.get_id().removesuffix('.desktop')
    names.extend([app_id,app_id.split('.')[-1]])
    symbolic=[theme.lookup_icon(name+'-symbolic',256,0) for name in dict.fromkeys(names) if theme.has_icon(name+'-symbolic')]
    candidates=symbolic+[theme.lookup_by_gicon(icon,256,Gtk.IconLookupFlags.FORCE_SYMBOLIC),
                theme.lookup_by_gicon(icon,256,0),
                theme.lookup_icon('application-x-executable',256,0)]
    pixbuf=None
    for info in candidates:
        if not info:continue
        try:
            color=Gdk.RGBA();color.parse('#24211d')
            pixbuf,_=info.load_symbolic(color,None,None,None)
            break
        except GLib.Error:
            try:pixbuf=info.load_icon();break
            except GLib.Error:continue
    if pixbuf is None:raise ValueError('Não foi possível carregar o ícone deste aplicativo.')
    ok,raw=pixbuf.save_to_bufferv('png',[],[])
    uri='data:image/png;base64,'+base64.b64encode(raw).decode()
    portrait={'imageBase64':uri}
    abilities=random.sample(['flying','deathtouch','reach','sharp','drawrabbits','squirrelstrafe','guarddog','tristrike'],random.randint(1,2))
    # The default Leshy frame stays fixed; randomize its printed attributes.
    return {'defaultVersion':2,'style':'leshy','card':{'name':app.get_display_name(),'useCustomPortrait':True,'portrait':portrait,'rare':False,'attack':random.randint(1,9),'health':random.randint(1,9),'bloodCost':random.randint(0,3),'boneCost':0,'abilities':[{'referenceId':a} for a in abilities]+[{'referenceId':''} for _ in range(5-len(abilities))],'tribes':random.sample(['canine','bird','insect','hooved','reptile'],1),'flags':random.choice([[],['blood'],['fused'],['gold']])},'logo':{'scale':50,'sources':portrait},'options':{'border':False,'scanlines':False,'locale':'default'}}

class Worker:
    def __init__(self, ids):
        self.ids=list(dict.fromkeys(ids)); self.window=None; self.web=None; self.timer=0; self.server=None
        GLib.idle_add(self.next)
    def next(self):
        if self.timer:GLib.source_remove(self.timer);self.timer=0
        if self.server:threading.Thread(target=self.server.shutdown,daemon=True).start();self.server=None
        if self.window:self.window.destroy();self.window=None
        if not self.ids:
            for queue in ROOT.glob('*.queue'):
                self.ids.append(queue.read_text());queue.unlink(missing_ok=True)
        while self.ids:
            self.aid=self.ids.pop(0).removesuffix(':flatpak'); self.key=hashlib.sha256(self.aid.encode()).hexdigest()
            self.path=ROOT/(self.key+'.json')
            if self.path.exists():
                try:
                    if json.loads(self.path.read_text()).get('defaultVersion')==2:continue
                except (ValueError,OSError):pass
            app=Gio.DesktopAppInfo.new(self.aid)
            if not app and Path(self.aid).is_file():app=Gio.DesktopAppInfo.new_from_filename(self.aid)
            if app:break
        else:Gtk.main_quit();return False
        try:
            plan=ROOT/(self.key+'.plan')
            initial=json.loads(plan.read_text()) if plan.exists() else {}
            if initial.get('defaultVersion')!=2:
                initial=initial_for(app);generator.atomic_json(plan,initial)
            abilities=initial['card'].get('abilities',[])
            initial['card']['abilities']=(abilities+[{'referenceId':''} for _ in range(5)])[:5]
            self.server=generator.ThreadingHTTPServer(('127.0.0.1',0),generator.Handler)
            self.server.initial=initial; self.server.secret=secrets.token_urlsafe(32)
            self.server.base='http://127.0.0.1:'+str(self.server.server_port)
            self.server.daemon_threads=True
            threading.Thread(target=self.server.serve_forever,daemon=True).start()
            manager=WebKit2.UserContentManager()
            for name in ['handStatus','handSave']:manager.register_script_message_handler(name)
            manager.connect('script-message-received::handStatus',self.status)
            manager.connect('script-message-received::handSave',self.saved)
            self.web=WebKit2.WebView.new_with_user_content_manager(manager)
            self.window=Gtk.OffscreenWindow();self.window.set_default_size(1000,700);self.window.add(self.web);self.window.show_all()
            self.web.load_uri(self.server.base+'/?token='+self.server.secret)
            self.timer=GLib.timeout_add_seconds(65,self.failed)
        except Exception as error:print(self.aid,error,flush=True);GLib.idle_add(self.next)
        return False
    def failed(self):
        self.timer=0
        (ROOT/(self.key+'.error')).write_text('O gerador não respondeu a tempo. Será tentado novamente.')
        GLib.idle_add(self.next);return False
    def status(self,manager,result):
        msg=json.loads(result.get_js_value().to_string())
        if msg['kind']=='ready':self.web.run_javascript('HandGenerator.save()',None,None,None)
        elif msg['kind']=='error':print(self.aid,msg['text'],flush=True);GLib.idle_add(self.next)
    def saved(self,manager,result):
        try:
            payload=json.loads(result.get_js_value().to_string())
            raw=base64.b64decode(payload['image'].split(',',1)[1],validate=True)
            if not raw.startswith(b'\x89PNG\r\n\x1a\n'):raise ValueError('Invalid PNG')
            image=ROOT/(self.key+'.png'); image.write_bytes(raw)
            generator.atomic_json(self.path,{'image':str(image),'generator':payload['draft'],'automatic':True,'defaultVersion':2})
            (ROOT/(self.key+'.error')).unlink(missing_ok=True)
            print('Carta padrão salva:',self.aid,flush=True)
        except Exception as error:print(error,flush=True)
        GLib.idle_add(self.next)

if __name__=='__main__':
    # Every invocation queues its IDs before acquiring the shared worker lock.
    for aid in sys.argv[1:]:
        aid=aid.removesuffix(':flatpak')
        key=hashlib.sha256(aid.encode()).hexdigest()
        (ROOT/(key+'.queue')).write_text(aid)
    lock=(ROOT/'.worker.lock').open('w')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:sys.exit(0)
    ids=[]
    for queue in ROOT.glob('*.queue'):
        ids.append(queue.read_text());queue.unlink(missing_ok=True)
    worker=Worker(ids);Gtk.main()
    fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
    sys.stdout.flush();sys.stderr.flush()
    os._exit(0)
