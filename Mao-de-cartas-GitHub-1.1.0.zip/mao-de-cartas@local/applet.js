const ByteArray = imports.byteArray;
const Cinnamon = imports.gi.Cinnamon;
const PopupMenu = imports.ui.popupMenu;
const Mainloop = imports.mainloop;
const Util = imports.misc.util;
const GLib = imports.gi.GLib;
const Applet = imports.ui.applet;
const Main = imports.ui.main;
const Settings = imports.ui.settings;
const St = imports.gi.St;
const Gio = imports.gi.Gio;
const Clutter = imports.gi.Clutter;
const Cogl = imports.gi.Cogl;
const GdkPixbuf = imports.gi.GdkPixbuf;
const Tweener = imports.ui.tweener;

class Hand extends Applet.TextIconApplet {
    constructor(metadata, orientation, height, id) {
        super(orientation, height, id);
        this.setAllowedLayout(Applet.AllowedLayout.BOTH);
        this.settings = new Settings.AppletSettings(this, metadata.uuid, id);
        this.layer = new St.Widget({reactive: false});
        Main.layoutManager.addChrome(this.layer, {affectsInputRegion: false, affectsStruts: false, visibleInFullscreen: false});
        this.open = true;
        this.tracker = Cinnamon.WindowTracker.get_default();
        this.pendingApps = new Set();
        this.autoRequested = new Set();
        this.defaultsPath = GLib.build_filenamev([GLib.get_user_data_dir(),'mao-de-cartas','defaults']);
        GLib.mkdir_with_parents(this.defaultsPath,448);
        this.defaultMonitor = Gio.File.new_for_path(this.defaultsPath).monitor_directory(Gio.FileMonitorFlags.NONE,null);
        this.defaultMonitor.connect('changed',(monitor,file)=>{if(file.get_basename().endsWith('.json')) this.scheduleWindows();});
        this.contextManager = new PopupMenu.PopupMenuManager(this);
        this.windowSignal = global.display.connect('window-created', () => this.scheduleWindows());
        this.workspaceSignal = global.window_manager.connect('destroy', () => this.scheduleWindows());
        this.editorPath = metadata.path + "/cards-editor.py";
        this.instanceId = id;
        for (let key of ['cards','size','overlap','formation','width','hidden','buttonIcon','buttonText'])
            this.settings.bind(key, key, () => this.rebuild());
        this.signal = Main.layoutManager.connect('monitors-changed', () => this.rebuild());
        this.editSignal = global.settings.connect('changed::panel-edit-mode', () => this.updateVisibility());
        this.autoRetry = Mainloop.timeout_add_seconds(300,()=>{this.autoRequested.clear();this.scheduleWindows();return true;});
        this.rebuild();
    }
    scheduleWindows() {
        if (this.windowTimer) Mainloop.source_remove(this.windowTimer);
        this.windowTimer = Mainloop.timeout_add(250, () => { this.windowTimer = 0; this.rebuild(); return false; });
    }
    dockCards() {
        let groups = new Map();
        global.get_window_actors().forEach(actor => {
            let win = actor.meta_window;
            if (!win || win.skip_taskbar) return;
            let app = this.tracker.get_window_app(win);
            if (!app || !app.get_id()) return;
            let id = app.get_id().replace(/:flatpak$/, '');
            if (!groups.has(id)) groups.set(id, []);
            groups.get(id).push(win);
            this.pendingApps.delete(id);
        });
        let configured = this.cards || [];
        let ids = configured.filter(c => c.pinned !== false).map(c => c.app);
        groups.forEach((wins,id) => { if (!ids.includes(id)) ids.push(id); });
        let result = [];
        let autoBatch = [];
        ids.forEach(id => {
            let template = configured.find(c => c.app === id) || {app:id};
            let usable = template.image && Gio.File.new_for_path(template.image).query_exists(null);
            if (!usable && !template.manual && !template.generator) {
                let key = GLib.compute_checksum_for_string(GLib.ChecksumType.SHA256,id,-1);
                let path = this.defaultsPath+'/'+key+'.json';
                try {
                    let [ok,bytes] = GLib.file_get_contents(path);
                    let cached = JSON.parse(ByteArray.toString(bytes));
                    template = Object.assign({},template,cached);
                    if (cached.defaultVersion !== 2 && !this.autoRequested.has(id)) {
                        this.autoRequested.add(id);autoBatch.push(id);
                    }
                } catch(e) {
                    if (!this.autoRequested.has(id)) {
                        this.autoRequested.add(id);
                        autoBatch.push(id);
                    }
                }
            }
            let wins = groups.get(id) || [];
            (wins.length ? wins : [null]).forEach((win,index) => result.push(Object.assign({},template,{window:win,stack:index,count:Math.max(1,wins.length),group:ids.indexOf(id)})));
        });
        if (autoBatch.length) Util.spawn(['/usr/bin/python3',GLib.path_get_dirname(this.editorPath)+'/auto-cards.py',...autoBatch]);
        this.dockCount = ids.length;
        return result;
    }
    editCards() {
        Util.spawn(['/usr/bin/python3', this.editorPath,
            this.settings.file.get_path()]);
    }
    on_applet_clicked() {
        if (global.settings.get_boolean('panel-edit-mode')) return;
        this.open = !this.open;
        this.animateHand(this.open);
    }
    animateHand(opening) {
        let cards = this.layer.get_children();
        let monitor = Main.layoutManager.primaryMonitor;
        if (!monitor || !cards.length) { this.updateVisibility(); return; }
        this.animationSerial = (this.animationSerial || 0) + 1;
        let serial = this.animationSerial;
        let wasVisible = this.layer.visible;
        this.animating = true;
        this.layer.show();
        let remaining = cards.length;
        cards.forEach(card => {
            Tweener.removeTweens(card);
            let pose = card._handPose;
            let foldedX = monitor.width / 2 - card.width / 2;
            let foldedY = monitor.height - card.height * .16;
            if (opening && !wasVisible) {
                card.set_position(foldedX, monitor.height + 20);
                card.rotation_angle_z = -9;
                card.opacity = 0;
            }
            let delay = (opening ? pose.index : cards.length - 1 - pose.index) * .045;
            Tweener.addTween(card, {
                x: opening ? pose.x : foldedX,
                y: opening ? pose.y : foldedY,
                rotation_angle_z: opening ? pose.angle : -9,
                opacity: 255,
                delay: delay, time: opening ? .46 : .28,
                transition: opening ? 'easeOutBack' : 'easeInOutQuad',
                onComplete: () => {
                    if (serial !== this.animationSerial) return;
                    if (opening) {
                        if (--remaining === 0) { this.animating = false; this.updateVisibility(); }
                    } else {
                        Tweener.addTween(card, {
                            y: monitor.height + 28, opacity: 0,
                            time: .26, transition: 'easeInQuad',
                            onComplete: () => {
                                if (serial !== this.animationSerial) return;
                                if (--remaining === 0) { this.animating = false; this.updateVisibility(); }
                            }
                        });
                    }
                }
            });
        });
    }
    updateVisibility() {
        this.layer.visible = this.open && this.layer.get_n_children() > 0 && !global.settings.get_boolean('panel-edit-mode');
    }
    clearCards() {
        this.animationSerial = (this.animationSerial || 0) + 1;
        this.animating = false;
        this.layer.get_children().forEach(card => {
            Tweener.removeTweens(card);
            Main.layoutManager.untrackChrome(card);
            card.destroy();
        });
    }
    rebuild() {
        if (!this.layer) return;
        this.set_applet_icon_name(this.buttonIcon || 'applications-games');
        if ((this.buttonIcon || '').startsWith('/')) this.set_applet_icon_path(this.buttonIcon);
        this.set_applet_label(this.buttonText || '');
        this.set_applet_tooltip('Mão de cartas — mostrar / esconder');
        let previous = new Set(this.layer.get_children().map(c => c._dockKey));
        this.layer.get_children().forEach(c => {
            if (c._dockItem && c._dockItem.window && !global.get_window_actors().some(a => a.meta_window === c._dockItem.window)) {
                Main.layoutManager.untrackChrome(c);
                let [gx,gy] = c.get_transformed_position();
                this.layer.remove_child(c); Main.uiGroup.add_child(c); c.set_position(gx,gy);
                c.reactive=false;
                Tweener.removeTweens(c);
                Tweener.addTween(c,{x:gx+150,y:gy-100,rotation_angle_z:45,opacity:0,time:.35,onComplete:()=>c.destroy()});
            }
        });
        this.clearCards();
        let m = Main.layoutManager.primaryMonitor;
        if (!m) return;
        this.layer.set_position(m.x, m.y);
        this.layer.set_size(m.width, m.height);
        let cards = this.dockCards(), n = this.dockCount;
        if (!n) { this.layer.visible = false; return; }
        let w = Math.min(this.size || 180, m.height * .55), h = w * 1.5;
        let available = m.width * (this.width || 65) / 100;
        w = Math.min(w, available); h = w * 1.5;
        let dimensions = cards.map(item => {
            let cw = w, ch = h;
            if (item.image) {
                try {
                    let [format, iw, ih] = GdkPixbuf.Pixbuf.get_file_info(item.image);
                    if (format && iw > 0 && ih > 0) {
                        let scale = Math.min(w / iw, h / ih);
                        cw = iw * scale; ch = ih * scale;
                    }
                } catch (e) { global.logError(e); }
            }
            return [cw, ch];
        });
        let step = n > 1 ? Math.min(w * (1 - this.overlap / 100), Math.max(0, (available-w)/(n-1))) : 0;
        let fan = 1 - this.formation / 100;
        let total = w + step * (n-1);
        cards.forEach((item, i) => {
            let [cw, ch] = dimensions[i];
            let app = Gio.DesktopAppInfo.new(item.app || '');
            let name = app ? app.get_display_name() : (item.app || 'Aplicativo indisponível');
            let card = new St.Button({reactive:true, can_focus:true, track_hover:true, accessible_name:name,
                style:'background-color: #e8d3a3; border: 3px solid #554024; border-radius: 12px; color: #332519;'});
            card.set_size(cw,ch);
            let box = new St.BoxLayout({vertical:true, style:'padding: 10px; spacing: 10px;'});
            if (item.image && Gio.File.new_for_path(item.image).query_exists(null)) {
                card.set_style('background-color: transparent; border: 0; border-radius: 0; padding: 0; margin: 0; box-shadow: none; background-image: none;');
                // Transparent texels around the source let the GPU interpolate the
                // silhouette instead of cutting a rotated opaque actor at its edge.
                let scale = Math.max(2, global.ui_scale || 1);
                let pw = Math.max(1, Math.round(cw * scale));
                let ph = Math.max(1, Math.round(ch * scale));
                let pad = 4;
                let source = GdkPixbuf.Pixbuf.new_from_file_at_scale(item.image, pw, ph, true);
                let pixels = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, true, 8, pw + pad * 2, ph + pad * 2);
                pixels.fill(0);
                source.copy_area(0, 0, source.get_width(), source.get_height(), pixels, pad, pad);
                let content = new Clutter.Image();
                content.set_data(pixels.get_pixels(), Cogl.PixelFormat.RGBA_8888,
                    pixels.get_width(), pixels.get_height(), pixels.get_rowstride());
                let texture = new Clutter.Actor({width: cw + pad * 2 / scale, height: ch + pad * 2 / scale});
                texture.set_content(content);
                texture.set_content_scaling_filters(Clutter.ScalingFilter.TRILINEAR, Clutter.ScalingFilter.LINEAR);
                let holder = new St.Widget({width: cw, height: ch, reactive: false});
                texture.set_position(-pad / scale, -pad / scale);
                holder.add_child(texture);
                card.set_child(holder);
            } else {
                box.add_child(new St.Label({text:'♠  ♥  ♣  ♦',style:'font-size: 20px;'}));
                box.add_child(new St.Icon({gicon: app ? app.get_icon() : new Gio.ThemedIcon({name:'application-x-executable'}),icon_size:Math.round(w*.45)}));
                box.add_child(new St.Label({text:name,style:'font-weight: bold;'}));
                card.set_child(box);
            }
            let t = n > 1 ? (item.group/(n-1)*2-1) : 0;
            let angle = t*22*fan;
            let x = (m.width-total)/2 + item.group*step + (w-cw)/2 + item.stack*9;
            let y = m.height-ch*(1-this.hidden/100)+Math.abs(t)*ch*.12*fan - item.stack*12;
            card.set_pivot_point(.5,1);
            card.rotation_angle_z=angle;
            card.set_position(x,y);
            card._dockKey = item.window ? 'window:'+item.window.get_stable_sequence() : 'pin:'+item.app;
            card._dockItem = item;
            card._handPose = {x: x, y: y, angle: angle, index: i};
            this.layer.add_child(card);
            Main.layoutManager.trackChrome(card, {affectsInputRegion: true, affectsStruts: false});
            let front = this.layer.get_children().find(c => c !== card && c._dockItem && c._dockItem.app === item.app && c._dockItem.stack === 0);
            if (front) this.layer.set_child_below_sibling(card, front);
            let select = active => {
                if (this.animating || !this.open) return;
                Tweener.removeTweens(card);
                if(active) this.layer.set_child_above_sibling(card,null);
                Tweener.addTween(card,{x:active ? x + (item.stack-(item.count-1)/2)*cw : x,y:active ? m.height-ch-12 : y, rotation_angle_z:active?0:angle,time:.18,transition:'easeOutQuad',onComplete:()=>{
                    if(!active && card.get_parent()) this.layer.set_child_at_index(card,i);
                }});
            };
            card._select = select;
            card.connect('notify::hover',()=>{
                let group = this.layer.get_children().filter(c=>c._dockItem.app===item.app);
                group.forEach(c=>c._select(group.some(other=>other.hover)));
            });
            if (!previous.has(card._dockKey) && previous.size) {
                card.y = m.height+20; card.rotation_angle_z = angle-18;
                Tweener.addTween(card,{y:y,rotation_angle_z:angle,time:.4,transition:'easeOutBack'});
            }
            card.connect('key-focus-in',()=>select(true));
            card.connect('key-focus-out',()=>select(false));
            let menu = new PopupMenu.PopupMenu(card, St.Side.BOTTOM);
            Main.uiGroup.add_child(menu.actor); menu.actor.hide();
            this.contextManager.addMenu(menu);
            card.connect('destroy', () => menu.destroy());
            let fresh = new PopupMenu.PopupMenuItem('Abrir nova janela');
            fresh.connect('activate', () => { let running = item.window ? this.tracker.get_window_app(item.window) : null; if (running) running.open_new_window(-1); else if (app) app.launch([],null); });
            menu.addMenuItem(fresh);
            let close = new PopupMenu.PopupMenuItem('Fechar janela');
            close.setSensitive(!!item.window);
            close.connect('activate', () => { if(item.window) item.window.delete(global.get_current_time()); });
            menu.addMenuItem(close);
            let pointer = null;
            menu._calculatePosition = () => {
                let [, , width, height] = menu.actor.get_preferred_size();
                let monitor = Main.layoutManager.findMonitorForActor(card);
                let [px,py] = pointer || global.get_pointer();
                return [Math.max(monitor.x,Math.min(px-width/2,monitor.x+monitor.width-width)),
                    Math.max(monitor.y,Math.min(py-height-8,monitor.y+monitor.height-height))];
            };
            card.connect('button-press-event', (actor,event) => { if(event.get_button()===3){ pointer=event.get_coords(); menu.toggle(); return Clutter.EVENT_STOP; } return Clutter.EVENT_PROPAGATE; });
            card.connect('clicked',()=>{try {
                if (item.window) Main.activateWindow(item.window);
                else if(app && !this.pendingApps.has(item.app)) { this.pendingApps.add(item.app); app.launch([],null); Mainloop.timeout_add(5000,()=>{this.pendingApps.delete(item.app);return false;}); }
            } catch(e) {this.pendingApps.delete(item.app);Main.notifyError('Mão de cartas',String(e));}});
        });
        this.updateVisibility();
    }
    on_applet_removed_from_panel() {
        Mainloop.source_remove(this.autoRetry);
        this.defaultMonitor.cancel();
        global.display.disconnect(this.windowSignal);
        global.window_manager.disconnect(this.workspaceSignal);
        if(this.windowTimer) Mainloop.source_remove(this.windowTimer);
        Main.layoutManager.disconnect(this.signal);
        global.settings.disconnect(this.editSignal);
        this.clearCards();
        Main.layoutManager.removeChrome(this.layer);
        this.layer.destroy(); this.settings.finalize();
    }
}
function main(metadata, orientation, height, id) { return new Hand(metadata,orientation,height,id); }
