/* Integration for the local Cinnamon applet. Original controls: generator.cards. */
window.HandGenerator = {
    initial: window.HAND_INITIAL || {},
    revision: 0, renderedRevision: -1, rendering: false, saving: false,
    tell(kind, text) {
        if (window.webkit?.messageHandlers?.handStatus)
            window.webkit.messageHandlers.handStatus.postMessage(JSON.stringify({kind, text}));
    },
    async fitPortrait(uri, width, height, percentage) {
        if (!uri) return undefined;
        const image = new Image(); image.src = uri;
        await image.decode();
        const canvas = document.createElement('canvas');
        canvas.width = width; canvas.height = height;
        const context = canvas.getContext('2d');
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = 'high';
        const ratio = Math.min(width / image.naturalWidth, height / image.naturalHeight) * percentage / 100;
        const w = image.naturalWidth * ratio, h = image.naturalHeight * ratio;
        context.drawImage(image, (width-w)/2, (height-h)/2, w, h);
        return canvas.toDataURL('image/png');
    },
    update(snapshot, render) {
        if (this.logo) snapshot.logo = this.logo;
        this.snapshot = JSON.parse(JSON.stringify(snapshot, (_, value) => value instanceof Set ? [...value] : value));
        this.render = render;
        this.revision++;
        this.tell('pending', 'Atualizando prévia…');
        if (!this.timer) this.timer = setTimeout(() => {
            this.timer = null; this.run();
        }, 150);
    },
    async run() {
        if (this.rendering || !this.render) return;
        this.rendering = true;
        const revision = this.revision;
        try {
            const uri = await this.render();
            if (!uri?.startsWith('data:image/png;base64,')) throw Error('O servidor não retornou uma imagem válida.');
            const image = document.getElementById('card-preview');
            if (!image) throw Error('A carta excede o limite de 1 MB do gerador. Reduza as imagens enviadas.');
            // While dragging, display each completed frame and queue the newest
            // state. Saving still waits for the exact current revision.
            image.src = uri;
            this.image = uri;
            this.renderedRevision = revision;
            if (revision === this.revision) {
                this.tell('ready', 'Prévia atualizada. Salvar carta aplica a imagem ao aplicativo.');
                if (this.saving) this.finishSave();
            }
        } catch (error) {
            this.saving = false;
            this.tell('error', 'Não foi possível gerar a prévia. Verifique a internet e altere uma opção para tentar novamente. ' + error.message);
        } finally {
            this.rendering = false;
            if (revision !== this.revision) this.run();
        }
    },
    save() {
        if (!this.snapshot) return;
        if (this.renderedRevision !== this.revision) {
            this.saving = true;
            this.tell('pending', 'Aguardando a prévia atual para salvar…');
            clearTimeout(this.timer); this.timer = null; this.run();
        } else this.finishSave();
    },
    finishSave() {
        this.saving = false;
        if (this.image && window.webkit?.messageHandlers?.handSave) {
            window.webkit.messageHandlers.handSave.postMessage(JSON.stringify({image: this.image, draft: this.snapshot}));
        }
    }
};
