#!/usr/bin/python3
import hashlib
import copy, json, os, subprocess, sys, tempfile
from pathlib import Path
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib, GdkPixbuf

class Editor(Gtk.Window):
    def __init__(self, path):
        super().__init__(title='Mão de cartas — Aplicativos e imagens')
        self.path = path
        self.cards = json.loads(path.read_text()).get('cards', {}).get('value', [])
        self.saved_cards = copy.deepcopy(self.cards)
        self.reload_source = 0
        self.default_monitor = None
        self.monitor = None
        self.apps = {a.get_id(): a for a in Gio.AppInfo.get_all() if a.get_id() and a.should_show()}
        self.set_default_size(900, 650)
        self.connect('destroy', self.closed)
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=16)
        self.add(root)
        root.pack_start(Gtk.Label(label='Marque os aplicativos que deseja fixar. Selecione uma carta para escolher sua imagem e posição.', xalign=0), False, False, 0)
        search = Gtk.SearchEntry(placeholder_text='Buscar aplicativo pelo nome…')
        root.pack_start(search, False, False, 0)
        self.store = Gtk.ListStore(bool, Gio.Icon, str, str)
        for aid, app in sorted(self.apps.items(), key=lambda x:x[1].get_display_name().casefold()):
            self.store.append([any(c['app']==aid and c.get('pinned',True) for c in self.cards), app.get_icon(), app.get_display_name(), aid])
        for aid in self.apps:
            if not any(c['app']==aid for c in self.cards): self.cards.append({'app':aid,'image':'','pinned':False})
        self.query = ''
        filtered = self.store.filter_new()
        filtered.set_visible_func(lambda m,it,_: self.query in m[it][2].casefold())
        def find(entry):
            self.query = entry.get_text().casefold(); filtered.refilter()
        search.connect('search-changed', find)
        pane = Gtk.Paned()
        root.pack_start(pane, True, True, 0)
        tree = Gtk.TreeView(model=filtered)
        toggle = Gtk.CellRendererToggle()
        def toggled(_, p):
            row = filtered[p]
            row[0] = not row[0]
            card = next(c for c in self.cards if c['app']==row[3]); card['pinned'] = row[0]
            self.refresh(); self.save()
        toggle.connect('toggled', toggled)
        tree.append_column(Gtk.TreeViewColumn('Fixar', toggle, active=0))
        tree.append_column(Gtk.TreeViewColumn('', Gtk.CellRendererPixbuf(), gicon=1))
        tree.append_column(Gtk.TreeViewColumn('Aplicativo', Gtk.CellRendererText(), text=2))
        scroll = Gtk.ScrolledWindow(); scroll.add(tree); pane.pack1(scroll, True, False)
        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=8)
        pane.pack2(right, True, False)
        right.pack_start(Gtk.Label(label='Sua mão de cartas — na ordem de exibição'), False, False, 0)
        self.hand = Gtk.ListStore(str, str)
        handview = Gtk.TreeView(model=self.hand, headers_visible=False)
        handview.append_column(Gtk.TreeViewColumn('Carta', Gtk.CellRendererText(), text=0))
        handview.get_selection().connect('changed', self.selected)
        self.selection = handview.get_selection()
        sc = Gtk.ScrolledWindow(); sc.set_min_content_height(150); sc.add(handview)
        right.pack_start(sc, True, True, 0)
        self.preview = Gtk.Image(); right.pack_start(self.preview, True, True, 0)
        controls = Gtk.Box(spacing=6)
        for title, callback in [('Escolher imagem…', self.choose), ('Gerar imagem', self.generate), ('Restaurar ícone', self.clear), ('↑', lambda _:self.move(-1)), ('↓', lambda _:self.move(1))]:
            button = Gtk.Button(label=title); button.connect('clicked', callback); controls.pack_start(button, False, False, 0)
        right.pack_start(controls, False, False, 0)
        self.status = Gtk.Label(xalign=0); root.pack_start(self.status, False, False, 0)
        self.refresh(); self.show_all()
        # Watch the directory: both this editor and the generator save atomically.
        self.monitor = Gio.File.new_for_path(str(self.path.parent)).monitor_directory(Gio.FileMonitorFlags.NONE, None)
        self.monitor.connect('changed', self.config_changed)
        defaults = Path(GLib.get_user_data_dir())/'mao-de-cartas'/'defaults'
        defaults.mkdir(parents=True,exist_ok=True)
        self.default_monitor = Gio.File.new_for_path(str(defaults)).monitor_directory(Gio.FileMonitorFlags.NONE,None)
        self.default_monitor.connect('changed',lambda monitor,file,other,event: self.selected(None) if file.get_basename().endswith('.json') else None)
    def current(self):
        if not hasattr(self, 'selection'): return None
        model, it = self.selection.get_selected()
        return next((c for c in self.cards if it is not None and c['app']==model[it][1]), None)
    def refresh(self, aid=None):
        current = self.current()
        if aid is None and current: aid = current['app']
        self.hand.clear()
        for c in self.cards:
            app = self.apps.get(c['app'])
            it = self.hand.append([app.get_display_name() if app else c['app'], c['app']])
            if c['app']==aid: self.selection.select_iter(it)
    def selected(self, _):
        if not hasattr(self, 'preview'): return
        self.preview.clear(); c = self.current()
        if not c: return
        try:
            image = c.get('image')
            if (not image or not Path(image).exists()) and not c.get('manual'):
                path = Path(GLib.get_user_data_dir())/'mao-de-cartas'/'defaults'/(hashlib.sha256(c['app'].encode()).hexdigest()+'.json')
                if path.exists():
                    cached=json.loads(path.read_text());image=cached.get('image')
                    if cached.get('defaultVersion')!=2 and not c.get('generator'): subprocess.Popen(['/usr/bin/python3',str(Path(__file__).with_name('auto-cards.py')),c['app']])
                elif not c.get('generator'):
                    subprocess.Popen(['/usr/bin/python3',str(Path(__file__).with_name('auto-cards.py')),c['app']])
            if image: self.preview.set_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale(image,150,225,True))
            elif c['app'] in self.apps: self.preview.set_from_gicon(self.apps[c['app']].get_icon(), Gtk.IconSize.DIALOG)
        except GLib.Error: pass
    def generate(self, _):
        card = self.current()
        if not card:
            self.status.set_text('Selecione primeiro uma carta na lista à direita.')
            return
        if not self.save(): return
        app = self.apps.get(card['app'])
        name = app.get_display_name() if app else card['app']
        try:
            subprocess.Popen(['/usr/bin/python3', str(Path(__file__).with_name('generator-window.py')),
                              str(self.path), card['app'], name])
        except OSError as error:
            self.status.set_text('Não foi possível abrir o gerador: ' + str(error))

    def config_changed(self, monitor, file, other_file, event):
        if not any(item and item.get_basename() == self.path.name for item in (file, other_file)):
            return
        if self.reload_source: GLib.source_remove(self.reload_source)
        self.reload_source = GLib.timeout_add(150, self.reload_config)

    def reload_config(self):
        self.reload_source = 0
        try:
            cards = json.loads(self.path.read_text()).get('cards', {}).get('value', [])
            current = self.current()
            aid = current['app'] if current else None
            self.cards = cards
            self.saved_cards = copy.deepcopy(cards)
            pinned = {card['app'] for card in cards if card.get('pinned',True)}
            for row in self.store: row[0] = row[3] in pinned
            self.refresh(aid)
            self.selected(None)
        except (OSError, ValueError, KeyError) as error:
            self.status.set_text('Não foi possível atualizar a lista: ' + str(error))
        return GLib.SOURCE_REMOVE

    def closed(self, _):
        if self.reload_source: GLib.source_remove(self.reload_source)
        if self.monitor: self.monitor.cancel()
        if self.default_monitor: self.default_monitor.cancel()
        Gtk.main_quit()

    def choose(self, _):
        c = self.current()
        if not c: self.status.set_text('Selecione primeiro uma carta na lista à direita.'); return
        dialog = Gtk.FileChooserDialog(title='Escolha a imagem da carta', transient_for=self, action=Gtk.FileChooserAction.OPEN)
        dialog.add_buttons('Cancelar', Gtk.ResponseType.CANCEL, 'Usar imagem', Gtk.ResponseType.OK)
        f = Gtk.FileFilter(); f.set_name('Imagens'); f.add_pixbuf_formats(); dialog.add_filter(f)
        preview = Gtk.Image(); dialog.set_preview_widget(preview)
        def update(d):
            try:
                preview.set_from_pixbuf(GdkPixbuf.Pixbuf.new_from_file_at_scale(d.get_preview_filename(),200,300,True)); d.set_preview_widget_active(True)
            except (GLib.Error, TypeError): d.set_preview_widget_active(False)
        dialog.connect('update-preview', update)
        if dialog.run()==Gtk.ResponseType.OK:
            c['manual']=True; c['image']=dialog.get_filename(); self.save(); self.selected(None)
        dialog.destroy()
    def clear(self, _):
        c=self.current()
        if c: c['manual']=True; c['image']=''; self.save(); self.selected(None)
    def move(self, delta):
        c=self.current()
        if not c: return
        i=self.cards.index(c); j=i+delta
        if 0<=j<len(self.cards):
            self.cards[i],self.cards[j]=self.cards[j],self.cards[i]; self.refresh(c['app']); self.save()
    def save(self):
        temporary = None
        try:
            data = json.loads(self.path.read_text())
            latest = {card['app']: card for card in data.get('cards', {}).get('value', [])}
            baseline = {card['app']: card for card in self.saved_cards}
            merged = []
            for card in self.cards:
                aid = card['app']
                # Keep generator settings written by the other window since our
                # last read. Only overwrite fields actually changed here.
                result = copy.deepcopy(latest.get(aid, card))
                old = baseline.get(aid, {})
                for key, value in card.items():
                    if key not in old or value != old[key]: result[key] = value
                for key in old.keys() - card.keys(): result.pop(key, None)
                merged.append(result)
            data.setdefault('cards', {'type': 'generic', 'default': []})['value'] = merged
            with tempfile.NamedTemporaryFile('w', dir=self.path.parent, prefix='.cards-editor-', delete=False) as file:
                temporary = file.name
                json.dump(data, file, ensure_ascii=False, indent=2)
                file.write('\n')
            os.replace(temporary, self.path)
            temporary = None
            self.cards = merged
            self.saved_cards = copy.deepcopy(merged)
            Gio.bus_get_sync(Gio.BusType.SESSION,None).call_sync('org.Cinnamon','/org/Cinnamon','org.Cinnamon','updateSetting',GLib.Variant('(ssss)',('mao-de-cartas@local',self.path.stem,'cards',json.dumps(self.cards))),None,Gio.DBusCallFlags.NONE,5000,None)
            self.status.set_text('Alterações salvas.')
            return True
        except Exception as error:
            self.status.set_text('Não foi possível atualizar: ' + str(error))
            return False
        finally:
            if temporary and os.path.exists(temporary): os.unlink(temporary)

if __name__=='__main__':
    Editor(Path(sys.argv[1])); Gtk.main()
