#!/usr/bin/python3
"""Install the bundled applet for the current user after system dependencies."""
import json
import os
import shutil
import sys
import tempfile
from datetime import datetime
from pathlib import Path


def install(source, data_home):
    if json.loads((source / 'metadata.json').read_text())['uuid'] != 'mao-de-cartas@local':
        raise ValueError('Pacote de applet inválido.')
    parent = data_home / 'cinnamon' / 'applets'
    parent.mkdir(parents=True, exist_ok=True)
    target = parent / 'mao-de-cartas@local'
    # Copy first so a failed copy never damages the previous installation.
    stage = Path(tempfile.mkdtemp(prefix='.mao-de-cartas-', dir=parent))
    backup = None
    try:
        shutil.copytree(source, stage / target.name, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        if target.exists():
            backup = data_home / 'mao-de-cartas' / 'backups' / datetime.now().strftime('%Y%m%d-%H%M%S-%f')
            backup.parent.mkdir(parents=True, exist_ok=True)
            target.rename(backup)
        try:
            (stage / target.name).rename(target)
        except Exception:
            if backup: backup.rename(target)
            raise
    finally:
        shutil.rmtree(stage, ignore_errors=True)
    print('Applet instalada em:', target)
    if backup: print('Versão anterior preservada em:', backup)
    print('Suas configurações e imagens existentes foram preservadas.')
    return target


if __name__ == '__main__':
    if os.geteuid() == 0:
        sys.exit('Execute instalar.sh como usuário normal, sem sudo.')
    try:
        import gi
        gi.require_version('Gtk', '3.0')
        gi.require_version('WebKit2', '4.1')
        from gi.repository import Gtk, WebKit2, GdkPixbuf, Gio, GLib
        if sys.version_info < (3, 9): raise RuntimeError('É necessário Python 3.9 ou posterior.')
        data_home = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
        install(Path(__file__).resolve().parent / 'mao-de-cartas@local', data_home)
    except Exception as error:
        sys.exit('Não foi possível instalar: ' + str(error) + '\nExecute instalar.sh para instalar as dependências automaticamente.')
