#!/bin/bash
set -euo pipefail

package_dir="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

echo 'Mão de cartas — instalação'
echo 'As dependências serão instaladas pelo gerenciador de pacotes do sistema.'
if [[ ${EUID} -eq 0 ]]; then
    echo 'Execute este instalador como seu usuário normal, sem sudo.'
    echo 'Ele solicitará a senha quando precisar instalar as dependências.'
    exit 1
fi
if ! command -v apt-get >/dev/null; then
    echo 'Este instalador requer Linux Mint ou outro sistema compatível com APT e Cinnamon.'
    exit 1
fi
if ! command -v sudo >/dev/null; then
    echo 'O comando sudo não está disponível. Instale o pacote .deb pelo gerenciador de programas.'
    exit 1
fi
if [[ ! -f "$package_dir/mao-de-cartas@local/metadata.json" ]]; then
    echo 'Extraia o pacote ZIP inteiro antes de executar instalar.sh.'
    exit 1
fi
sudo -v
sudo apt-get update
sudo apt-get install -y cinnamon python3 python3-gi gir1.2-gtk-3.0 gir1.2-webkit2-4.1 gir1.2-gdkpixbuf-2.0 gir1.2-glib-2.0 gir1.2-clutter-1.0 gir1.2-cogl-1.0 ca-certificates
cinnamon_version="$(dpkg-query -W -f='${Version}' cinnamon)"
if ! dpkg --compare-versions "$cinnamon_version" ge '6.0'; then
    echo 'Esta versão do pacote exige Cinnamon 6.0 ou posterior. Atualize o sistema antes de instalar.'
    exit 1
fi
/usr/bin/python3 "$package_dir/instalar.py"
echo
echo 'Pronto! Clique com o botão direito no painel > Applets > Mão de cartas > Adicionar.'
echo 'Depois, clique com o botão direito em Cartas > Configurar.'
