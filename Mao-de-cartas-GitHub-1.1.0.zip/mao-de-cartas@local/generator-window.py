#!/usr/bin/python3
"""Local host for generator.cards controls, with automatic preview and per-app saving."""
import base64
import hashlib
import json
import os
import secrets
import sys
import tempfile
import threading
from functools import partial
from http.cookies import SimpleCookie
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlsplit, parse_qs, unquote
from urllib.request import Request, urlopen
import gi
gi.require_version('Gtk', '3.0')
gi.require_version('WebKit2', '4.1')
from gi.repository import Gtk, WebKit2, Gio, GLib, Gdk

ROOT = Path(__file__).resolve().parent / 'generator-site'
REMOTE = 'https://generator.cards'
MAX_IMAGE = 20 * 1024 * 1024


def atomic_json(path, data):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile('w', dir=path.parent, prefix='.cards-', delete=False) as f:
            temporary = f.name
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write('\n')
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary): os.unlink(temporary)


def save_card(config_path, app_id, payload, data_dir=None, notify=True):
    uri = payload.get('image', '')
    if not uri.startswith('data:image/png;base64,'): raise ValueError('Formato de imagem inválido.')
    raw = base64.b64decode(uri.split(',', 1)[1], validate=True)
    if len(raw) > MAX_IMAGE or not raw.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('Imagem inválida ou grande demais.')
    draft = payload.get('draft')
    if not isinstance(draft, dict) or not isinstance(draft.get('card'), dict):
        raise ValueError('Configurações da carta inválidas.')
    data = json.loads(config_path.read_text())
    card = next((c for c in data['cards']['value'] if c['app'] == app_id), None)
    if card is None: raise ValueError('O aplicativo foi removido da mão. Fixe-o novamente antes de salvar.')
    folder = data_dir or Path(GLib.get_user_data_dir()) / 'mao-de-cartas' / 'cards'
    folder.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256((app_id + uri).encode()).hexdigest()[:24]
    image_path = folder / (digest + '.png')
    with tempfile.NamedTemporaryFile('wb', dir=folder, delete=False) as f:
        temporary = f.name; f.write(raw)
    os.replace(temporary, image_path)
    card['image'] = str(image_path)
    card['generator'] = draft
    card['manual'] = True
    atomic_json(config_path, data)
    if notify:
        Gio.bus_get_sync(Gio.BusType.SESSION, None).call_sync(
            'org.Cinnamon', '/org/Cinnamon', 'org.Cinnamon', 'updateSetting',
            GLib.Variant('(ssss)', ('mao-de-cartas@local', config_path.stem, 'cards', json.dumps(data['cards']['value']))),
            None, Gio.DBusCallFlags.NONE, 5000, None)
    return image_path


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_): pass
    def reply(self, code, content, mime='text/plain; charset=utf-8', cookie=False):
        self.send_response(code)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        if cookie:
            self.send_header('Set-Cookie', 'hand_session='+self.server.secret+'; HttpOnly; SameSite=Strict; Path=/')
        self.end_headers()
        try: self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError): pass
    def authorized(self):
        cookie = SimpleCookie(self.headers.get('Cookie', ''))
        return 'hand_session' in cookie and secrets.compare_digest(cookie['hand_session'].value, self.server.secret)
    def do_GET(self):
        url = urlsplit(self.path)
        first = url.path == '/' and parse_qs(url.query).get('token') == [self.server.secret]
        if not first and not self.authorized(): self.reply(403,b'Forbidden'); return
        if url.path == '/initial.js':
            body = ('window.HAND_INITIAL = '+json.dumps(self.server.initial, ensure_ascii=True)+';').encode()
            self.reply(200,body,'application/javascript'); return
        name = 'index.html' if url.path == '/' else unquote(url.path).lstrip('/')
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file(): self.reply(404,b'Not found'); return
        types = {'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.woff2':'font/woff2','.png':'image/png'}
        self.reply(200,path.read_bytes(),types.get(path.suffix,'application/octet-stream'),cookie=first)
    def do_POST(self):
        if not self.authorized() or self.headers.get('Origin') != self.server.base:
            self.reply(403,b'Forbidden'); return
        length = int(self.headers.get('Content-Length', '0'))
        if not 0 < length <= 4 * 1024 * 1024: self.reply(413,b'Payload too large'); return
        action = self.headers.get('Next-Action','')
        if action != '70dd28c699ac9ef9a15e5065c4be161f12fe384e1e':
            self.reply(400,b'Unknown action'); return
        headers = {'Content-Type':self.headers.get('Content-Type','text/plain;charset=UTF-8'),
                   'Next-Action':action,'Origin':REMOTE,'Accept':'text/x-component',
                   'User-Agent':'MaoDeCartas/1.0 (generator.cards embedded editor)'}
        # Keep original Next.js serialization, including Sets and uploaded portraits.
        for key in ('Next-Router-State-Tree','Next-Url'):
            if self.headers.get(key): headers[key]=self.headers[key]
        body = self.rfile.read(length)
        try:
            with urlopen(Request(REMOTE+'/', data=body, headers=headers),timeout=45) as response:
                self.reply(response.status,response.read(32 * 1024 * 1024),response.headers.get('Content-Type','text/x-component'))
        except HTTPError as error:
            self.reply(error.code,error.read(),error.headers.get('Content-Type','text/plain'))
        except Exception:
            self.reply(502,b'Card renderer unavailable. Check your internet connection.')


class Generator(Gtk.Window):
    def __init__(self, config_path, app_id, app_name):
        super().__init__(title='Gerar imagem — '+app_name)
        self.config_path, self.app_id = config_path, app_id
        screen = Gdk.Screen.get_default()
        self.set_default_size(min(1120, screen.get_width()-60), min(740, screen.get_height()-100))
        data = json.loads(config_path.read_text())
        card = next((c for c in data['cards']['value'] if c['app']==app_id), None)
        if not card: raise ValueError('Selecione um aplicativo fixado.')
        cached = {}
        if not card.get('manual'):
            path = Path(GLib.get_user_data_dir())/'mao-de-cartas'/'defaults'/(hashlib.sha256(app_id.encode()).hexdigest()+'.json')
            if path.exists(): cached = json.loads(path.read_text())
        initial = card.get('generator', cached.get('generator', {'card': {'name':app_name}}))
        self.server = ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.server.daemon_threads = True
        self.server.initial, self.server.secret = initial, secrets.token_urlsafe(32)
        self.server.base = 'http://127.0.0.1:'+str(self.server.server_port)
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=6)
        self.add(root)
        bar = Gtk.Box(spacing=12,margin=10)
        self.status = Gtk.Label(label='Carregando editor…', xalign=0, hexpand=True)
        self.status.set_line_wrap(True)
        bar.pack_start(self.status,True,True,0)
        self.save_button = Gtk.Button(label='Salvar carta')
        self.save_button.set_sensitive(False)
        self.save_button.connect('clicked', lambda _: self.web.run_javascript('window.HandGenerator.save()',None,None,None))
        bar.pack_end(self.save_button,False,False,0)
        root.pack_start(bar,False,False,0)
        manager = WebKit2.UserContentManager()
        manager.register_script_message_handler('handStatus')
        manager.register_script_message_handler('handSave')
        manager.connect('script-message-received::handStatus',self.message)
        manager.connect('script-message-received::handSave',self.save)
        self.web = WebKit2.WebView.new_with_user_content_manager(manager)
        self.web.get_settings().set_enable_developer_extras(False)
        self.web.connect('decide-policy',self.policy)
        self.web.connect('load-failed',self.load_failed)
        root.pack_start(self.web,True,True,0)
        foot = Gtk.Label(label='Prévia automática via generator.cards • Requer internet • A carta salva fica no computador',margin=6)
        root.pack_end(foot,False,False,0)
        self.connect('destroy',self.close_editor)
        self.web.load_uri(self.server.base+'/?token='+self.server.secret)
        self.show_all()
    def policy(self, web, decision, kind):
        if kind in (WebKit2.PolicyDecisionType.NAVIGATION_ACTION, WebKit2.PolicyDecisionType.NEW_WINDOW_ACTION):
            uri = decision.get_navigation_action().get_request().get_uri()
            if not uri.startswith(self.server.base+'/'):
                decision.ignore()
                if uri.startswith(('https://','http://')):
                    Gio.AppInfo.launch_default_for_uri(REMOTE+urlsplit(uri).path if uri.startswith(self.server.base) else uri,None)
                return True
            path = urlsplit(uri).path
            if path not in ('/',):
                decision.ignore(); Gio.AppInfo.launch_default_for_uri(REMOTE+path,None); return True
        return False
    def load_failed(self, web, event, uri, error):
        self.status.set_text('Não foi possível abrir o editor: '+error.message)
        return False
    def message(self, manager, result):
        try:
            message = json.loads(result.get_js_value().to_string())
            self.status.set_text(message['text'])
            self.save_button.set_sensitive(message['kind']=='ready')
        except Exception as error: self.status.set_text(str(error))
    def save(self, manager, result):
        try:
            save_card(self.config_path,self.app_id,json.loads(result.get_js_value().to_string()))
            self.status.set_text('Carta salva em '+self.app_id+'. A mão e a lista de aplicativos foram atualizadas.')
        except Exception as error: self.status.set_text('Não foi possível salvar a carta: '+str(error))
    def close_editor(self, *_):
        threading.Thread(target=self.server.shutdown,daemon=True).start()
        Gtk.main_quit()


if __name__=='__main__':
    try:
        Generator(Path(sys.argv[1]),sys.argv[2],sys.argv[3]); Gtk.main()
    except Exception as error:
        dialog = Gtk.MessageDialog(message_type=Gtk.MessageType.ERROR,buttons=Gtk.ButtonsType.CLOSE,text='Não foi possível abrir o gerador',secondary_text=str(error))
        dialog.run(); dialog.destroy()
